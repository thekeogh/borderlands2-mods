# Native region override feasibility test — 0.1.5

Use the same copied test save. No reset, combat, reward collection or opening replay needed.

1. Fully quit Borderlands 2. Replace the installed package with 0.1.5.
2. Launch, enable One Playthrough, load your test save and wait for the HUD.
3. Mods → One Playthrough → **Test native region override (quit afterward)**, once.
4. Wait for the JSON export, then fully quit the game immediately. Do not resume gameplay.
   The option changes its text to a completion/restart message; a HUD popup is not required.
   The export status option and files on disk remain the confirmation.
5. Move the new `region_override_experiment` JSON into logs/ and tell the agent. Include
   a `-recovered.json` if one appears. No F10 or second experiment is required.

This differs from the previous threshold test. It invokes the game's reflected native
SetGameStageOverride setter with the character's actual level and compares the native
outputs for several already-loaded regions. The previous override value cannot be read
through a verified API, so the mod does not pretend to restore it or guess a reset value.
**Quitting/restarting is required. Disabling the mod alone is not a reset.**

The mod makes no save, reward, actor-level or mission-record writes during the probe. This
is not permission to continue a playthrough with the override: scope is deliberately under
investigation and native offsets may differ. Keep using a disposable copy. If the setter
fails after being attempted, restart still applies. A second data experiment is blocked in
this process; don't repeat the action merely because the HUD popup is hidden.

Ordinary F10 and Export scaling probe JSON remain observational/read-only. The old threshold
experiment is hidden. Reports remain JSON under
`<game>/sdk_mods/settings/one_playthrough/diagnostics/`. No console or executable changes.

The next result answers whether a supported native override can bypass the observed floor
and whether several regions change together. It does not yet establish a playable correction,
accepted mission migration, full UVHM tuning, native offsets or persistence.
