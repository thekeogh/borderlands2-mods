# Validation — 0.1.2

Offline validation on 2026-11-05: **36 tests passed** using Python 3.9.6. Engine tests use
deliberately limited fakes to test JSON robustness and observer behaviour; they cannot establish real
Unreal layouts, hook firing, UI coverage, vanilla UVHM fidelity, or a floor correction.

Run from the project root:

```sh
python3 -m unittest discover -s src/tests -v
python3 src/build.py
```

The packager compiles source without importing game dependencies; checks required modules,
relative imports, release metadata and documentation; and verifies the exact `.sdkmod`
member layout and archive integrity. It refuses missing files and an existing same-version
release. New releases archive previous version folders into verified `.zip` files, preserving
their contents, and leave the current release folder loose. A `.sdkmod` itself is the SDK's
required ZIP-format installable package; don't wrap the current release in another ZIP.

No executable changes, direct save edits, game-console commands or project `logs/` writes.
No gameplay corrections, mission migrations, custom profiles or OP selector.

User-supplied in-game evidence: 11 completed 0.1.0 JSON reports. Genuine UVHM, OP 0,
F10 disk export, level-50 missions/enemies and a level-1-to-10 change around the first turn-in
are observed. All 0.1.0 event hooks had zero hits because of malformed paths; its armed
screen capture failed. See INVESTIGATION.md for filenames and limits of those conclusions.

Actual 0.1.2 in-game checks: **pending** the short session in TESTING.md. The responsible
floor and SDK gameplay correction remain unresolved. No claim of completed level-1 UVHM.

Passing offline coverage: bounded history and detached snapshots; array/struct distinction;
formula preservation; private-field filtering; missing/non-finite values; atomic replacement
failure and interrupted collection; partial collection; read-only level/mission comparisons;
reflected hook registration/pass-through/removal; armed UI capture; entrypoint metadata/F10;
write-failure notification; package layout, missing-file rejection, same-version protection
and verified previous-release archiving. All files in the SDK archive compile successfully.

New regression coverage: SDK-shaped colon paths, inherited function owners, MStatus argument
identity, live actors versus archetypes, stage priority within field bounds, deeper regen
formulas, lifecycle retention under query churn, and completion-screen capture while ignoring
generic HUD refresh. The path test dispatches to the literal correct engine function key;
the old fake used dotted function names and failed to catch the original bug.

Version 0.1.2 adds offline coverage of bounded economy/combat histories, PRE/POST XP state,
combat damage arguments and actor levels, equipped gear without full inventory traversal,
the explicit QuestAccept reward-card path, and explicit mission arguments taking precedence
over unrelated missions on a UI object. Packaging requires the new activity.py module.
All added native action targets are reflected before registration; actual coverage and field
availability remain unverified until the next game session.
