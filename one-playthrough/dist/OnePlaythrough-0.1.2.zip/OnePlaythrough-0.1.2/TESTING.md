# Reset-save capture session — 0.1.2

Use this build for the planned replay through the first bullymongs. Completely exit the game,
replace the installed `one_playthrough.sdkmod` with 0.1.2, and enable it. Keep using the copied,
reset level-1 genuine UVHM save on an unpatched executable. No console commands.

Press F10 at these points as they happen naturally:

1. First playable HUD, before doing anything.
2. Each inventory/status screen you inspect, including journal and the first gun's item card.
3. After collecting money/ammo; after a dropped weapon pickup if one occurs.
4. Mission ready to turn in: with the check-in/reward screen open, **before claiming**.
5. **Immediately after claiming the first gun reward**, before doing anything else.
6. First enemies visible, after your melee hit if practical, and after death/respawn.

The before/after reward pair matters most: it helps compare accepted mission stage,
player XP/level, currency and generated gun data across the same turn-in. Event records
also preserve PRE/POST data where those reflected hooks actually fire. No extra combat
beyond your planned test is required. Don't try to beat the level-50 enemies.

Optional extra: after these captures, save-quit, reload the same character and press F10 once.
This checks which mission stages persist through reload. Use the game's ordinary save flow;
F10 never forces a save. Report any changed weapon-slot/unlock presentation you notice.

Optional fallback test: arm **Capture next mission screen** in mod options before opening
the completion/reward screen. This build explicitly observes the reference's QuestAccept
reward-card function as well as dynamically discovered mission UI functions. Actual game
hook coverage still needs testing. If no automatic JSON appears, ordinary F10 or **Export
JSON now** still captures recent events. Tell us which screen you tried.

Copy files from `<game>/sdk_mods/settings/one_playthrough/diagnostics/` into this project's
`logs/` folder. Multiple captures/duplicates are fine. Identify the before/after reward
files and any visibly wrong inventory level, money/ammo result, mission level or UI text.
A brief HUD notification confirms exports when available; the mod options' **JSON export
status / location** shows the last destination/error. An automatic `mod_enabled` JSON
also appears; it does not replace the in-game captures.

0.1.2 still observes only: missions, gun rewards and enemies can remain level 50, and the
first turn-in can again overlevel the test character. No gameplay correction, save migration,
executable patch, reward grant or inventory rewrite is included. Do not use a valued save.

`export_complete` means collection finished. `partial` means evidence was inaccessible,
truncated or failed; partial reports remain useful. Resource pools may expose handles rather
than exact ammo/health counts. Event payloads do not establish the exact rendered Flash text.
Native hook firing, field availability and armed capture remain subject to this game test.
