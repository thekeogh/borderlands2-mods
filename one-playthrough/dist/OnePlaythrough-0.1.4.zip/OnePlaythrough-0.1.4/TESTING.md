# One temporary threshold experiment — 0.1.4

The five current 0.1.3 reports were reviewed separately from logs/archive/. The small file
is a valid partial checkpoint from the failed export. Later reports and the scaling probe
succeeded. The native region stage is 50 at player level 10 even though default region bounds
are 1–2. Character maximum is 80. The first ammo-chest performance test is encouraging.

The next test checks the brief's remaining small data-field lead; it is not a playable fix.

1. Fully exit the game, replace the package with 0.1.4, enable and load the same test copy.
   No save reset needed.
2. Mod options → **Test UVHM threshold temporarily (restart afterward)**, once.
3. Wait for its JSON notification, then quit/restart the game. No combat, reward turn-in,
   chest test or further gameplay is required.
4. Return the `threshold_experiment` JSON from the usual diagnostics folder. If a normal
   file and a `-recovered.json` both appear, include both. Any startup/F10 files are welcome.

This explicit action snapshots only the first native PT3 tuning MinEffectiveLevel (50),
temporarily sets it to 1, compares region/mission getters, and restores 50 before returning.
The report includes baseline, during-test and after-restore values plus restoration checks.
Later thresholds, combat multipliers, mission records, actor levels, inventory and saves
are not edited. Restart clears any unverified native cached effects. If restoration fails,
the notification explicitly requires restarting; quit immediately if that happens.

Ordinary F10 remains strictly observational and never runs this experiment. The ordinary
**Export scaling probe JSON** is also read-only. This new option is deliberately separate
and clearly labelled because it temporarily changes one runtime data field.

Export now retries transient permission failures during replacement within a bounded 350 ms.
If an existing checkpoint remains locked, it tries a fresh recovery filename with full data
and error details. If both writes fail, copy the mod-menu export status/error text into your
message. No need for console access, changing permissions or disabling security software.

Files: `<game>/sdk_mods/settings/one_playthrough/diagnostics/`. JSON schema 4 uses event_table
and event_ref; partial captures are still useful. Continue moving older test batches to
logs/archive/ as you prefer. The agent reads logs/ root as the current test batch.
