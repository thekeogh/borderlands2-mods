# One Playthrough 0.1.4 — keogh

This is the first **diagnostic prototype**. It observes genuine UVHM and exports JSON.
It does **not yet remove the level-50 floor**, change tuning, lock mission levels, or fix UI.
The next correction depends on evidence from an unpatched game. Do not start a valued
long-term playthrough expecting the complete mod yet.

1. Install the modern [Willow2 PythonSDK/mod manager](https://bl-sdk.github.io/willow2-mod-db/).
2. Put `one_playthrough.sdkmod` directly into the game's `sdk_mods/` folder.
   Do not unzip it; remove an older installed copy of this same package first.
3. Launch Borderlands 2. Enable **One Playthrough** in Mods. Author: **keogh**; version: **0.1.4**.
4. Enabling produces a startup JSON. During gameplay, press **F10** to export another.
   No console commands or console interaction are required.

Reports are written under the actual SDK settings directory:
`<game>/sdk_mods/settings/one_playthrough/diagnostics/`.
They have unique UTC timestamped `.json` names. Copy them to the project's `logs/` folder.
The mod never writes to this project's `logs/` folder.

An in-game HUD message confirms export when the HUD is available. Mod options →
**JSON export status / location** shows the destination or last error, including in menus.
No HUD during loading/menu states is normal; inspect the folder or status option.
Exports use disk JSON exclusively; no console reporting.

For this update, completely exit the game before replacing `one_playthrough.sdkmod`.
Version 0.1.0 registered malformed hook paths; restarting avoids retaining those registrations.
Use only the new current package from `dist/OnePlaythrough-0.1.4/`.

Use a **copy** of a level-1 save already in genuine UVHM (playthrough index `2`), on an
unpatched game. Normal New Game does not become UVHM through this build. No save editing
or automatic save preparation is included. Non-zero OP selection is outside initial scope.
Disable other scaling/tuning mods for baseline captures; their overrides can affect evidence.

The supplied older Level 1 UVHM reference's readme says its prepared saves unlock additional
weapon slots. Those saves have not been parsed or validated here. Check the actual starting
save's slots and progression; do not assume it is a clean level-1 character.

Disable in Mods to remove observers and the F10 binding. No gameplay/save/executable
changes require restoration in this diagnostic build. Remove the `.sdkmod` to uninstall;
existing JSON reports remain. Solo BL2 only; multiplayer and TPS untested/unsupported.

Version 0.1.3 also offers **Export scaling probe JSON** in mod options. Use it only after
loading the test character. This separate action evaluates the already-reflected read-only
mission/region getters, including their output parameters. Ordinary F10 does not run these
queries. JSON schema 4 stores event payloads once under `event_table`; `event_ref` points
there. Report location and file extension are unchanged.

Version 0.1.4 adds an explicitly separate **Test UVHM threshold temporarily (restart afterward)**
option. Only that action changes a runtime field: the first PT3 tuning MinEffectiveLevel is
snapshotted, changed from 50 to 1 for read-only comparisons, then restored. Later thresholds,
combat multipliers, actors, owned items and saves are not edited. Quit/restart after the test;
hidden native caching is not proven reversible. F10 and the ordinary scaling probe never
perform the data experiment. A failed restoration produces an explicit restart notification.

Transient PermissionError during atomic replacement is retried up to three times (350 ms
total wait). If final replacement still fails, a new `-recovered.json` filename preserves
collected data and the original exception details. The original partial checkpoint remains.
If both writes fail, the HUD/mod options report the failure; no console is required.
