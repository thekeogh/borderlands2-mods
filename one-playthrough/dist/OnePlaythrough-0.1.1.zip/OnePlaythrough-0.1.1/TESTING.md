# Next capture session — 0.1.1

The first 11 reports were useful: genuine UVHM/OP 0 is confirmed, missions and enemies
really are level 50, and the character goes from level 1 to 10 across the first mission
completion. They also exposed malformed observer paths in 0.1.0. That bug prevented all
event hooks from firing, including the armed screen capture. It is corrected in source;
actual hook firing in 0.1.1 still needs this short test.

1. Completely exit the game. Replace the installed `one_playthrough.sdkmod` with **0.1.1**.
2. Enable the mod, load the same test character, and wait for the HUD. Press F10.
3. Open the journal on **Blindsided** (or whichever mission is active). Press F10 there,
   then close the journal and press F10 once more.
4. Return those JSON files through the project's `logs/` folder.

No combat, grinding or further mission completion is needed for this session. The existing
test character is sufficient even though the first reward has already raised it to level 10.
If an untouched level-1 copy is already available, it is useful to load that instead and
capture the first automatically assigned mission; don't edit the progressed save just for this.
Version 0.1.1 still observes only. Enemies, missions and rewards can remain level 50.

If a mission offer or completion/reward screen is naturally available, capture it with F10
before claiming rewards. Don't complete extra missions merely to produce a report.

Optional fallback test: Mods → One Playthrough → **Capture next mission screen**, then open
the journal/offer/completion screen. The corrected reflected hooks should now be able to
trigger it. It ignores the generic HUD mission refresh and reward popup, and accepts mission
data-population events or relevant functions on discovered mission movie/provider classes.
This remains dependent on which real screen functions fire. If no file appears, use ordinary
F10 after closing the screen, or **Export JSON now**. Tell us which screen you tried.

Files: `<game>/sdk_mods/settings/one_playthrough/diagnostics/`. No console required.
The mod options' **JSON export status / location** shows the most recent destination/error.
An automatic `mod_enabled` report also appears; the F10 reports after loading matter most.

Tell the agent which files correspond to gameplay/journal/offer/reward, what the UI displayed,
whether the executable is unpatched, and which other scaling mods were enabled. The new
reports distinguish registered hooks from observed hits, include exact function paths and
parameters, and retain acceptance/reward events separately from frequent level queries.
Rendered Flash text is not assumed to equal a captured event payload.

`export_complete` means collection finished. `partial` means some evidence was unavailable,
truncated or failed; partial reports remain useful. F10 reads only—no save, stage, tuning,
inventory, reward or mission-state writes.

The full gameplay acceptance matrix in `agent/context.md` remains pending a justified SDK
correction. Offline tests and working export alone cannot establish that scaling is fixed.
