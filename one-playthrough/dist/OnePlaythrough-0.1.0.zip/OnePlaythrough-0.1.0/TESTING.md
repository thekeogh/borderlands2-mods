# First capture session

Use a copied save and an unpatched game. Version 0.1.0 deliberately collects a baseline;
level-50 enemies or mission offers can still occur. No console needed at any point.

1. Enable the mod. Confirm author/version and locate the automatically exported `mod_enabled` JSON.
2. Load the level-1 genuine UVHM save. Press F10 before interacting with the first mission.
3. Open its offer. Note the mission name, displayed level and difficulty in ordinary words;
   press F10 **while the offer is visible**. If an initial story mission was already assigned,
   capture its journal entry and identify that fact; don't reset it to manufacture an offer.
4. On this test copy only, accept a mission. Press F10, open the journal and press F10 again.
5. If practical, capture the same accepted mission after a normal level-up, map transition,
   save-quit/reload, and on its reward screen. Press F10 immediately after transient fanfare.
6. Optionally capture a separate level-50+ UVHM character for comparison. Explicitly label
   that report as the comparison character, with any other active mods.

For the first hand-off, steps 1–4 are sufficient to begin investigation. Do not grind levels
or complete the full acceptance matrix before returning the first reports.

Copy these JSON files into the project's `logs/` folder. Tell the coding agent:

- What happened versus what you expected; mission/map and visible level/difficulty.
- Which filenames correspond to offer, acceptance, journal or comparison.
- Whether the executable is unpatched and other scaling mods were disabled.
- Whether F10 worked with each affected screen open.

If F10 does not export with a screen open: Mods → One Playthrough → **Capture next mission
screen**, then return to/open the affected mission screen. The next observed mission UI
event writes JSON automatically, after its payload is recorded. This fallback also needs
in-game verification: it depends on an available, firing UI hook. If no file appears, use
**Export JSON now** from mod options and return that JSON plus the startup report. Recent
events remain bounded in memory, so capture promptly. No unsupported input workaround or
console command is required. F10 can also be rebound in the normal SDK controls menu.

`export_complete` means collection finished and the final JSON was committed. `partial`
means evidence was inaccessible, truncated or failed; a partial report is still useful.
Unavailable fields explain why; they never silently become level zero. Rendered Flash text
is not assumed to equal a captured event payload—include your observed UI values.

F10 observes only: no stage edits, rewards, saves or tuning. File export and the brief
confirmation are its only intended effects. Notify us if the capture itself changes gameplay.

Full gameplay acceptance remains pending: mission acceptance locks (including automatic,
alternate and repeatable missions), rewards/XP/cash, travel/reload, native enemy offsets and
regen, drops/vendors, DLCs, 49/50/51 boundaries and installed maximum level. These cannot be
claimed from offline tests or from the first diagnostic session.
