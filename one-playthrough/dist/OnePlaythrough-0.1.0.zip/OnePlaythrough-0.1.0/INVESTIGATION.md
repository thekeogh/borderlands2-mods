# Feasibility investigation — 0.1.0

## Established from source, not in-game observation

- The older supplied `Level 1 UVHM/ReadMe.txt` requires an executable edit and prepared saves.
  Its listed byte sequence changes an immediate comparison constant from hexadecimal `32`
  (decimal 50) to `01`. This supports a native comparison hypothesis; **it does not identify
  the owning function, authoritative stage calculation, or prove all affected paths**.
  No executable was supplied, opened, patched or searched. No prepared save was parsed.
- The supplied AVHM source replaces balance multipliers, disables regeneration, flattens
  stages and raises rewards after acceptance. None of that implementation was carried over.
- The modern Enemy and Item Scaling reference identifies useful factory and mission record
  paths, and explicitly levels accepted missions. Its policy is unsuitable here. References
  were read for investigation; no reference mod code was copied.
- A first `MinEffectiveLevel` tuning threshold is a separate investigation lead. Changing it
  alone is not evidence that mission, region or native world-stage floors are removed.

## Verified SDK surface

Inspected official source and stubs on 2026-11-04:

- [mods_base](https://github.com/bl-sdk/mods_base): `SETTINGS_DIR`, `build_mod`, `ButtonOption`,
  modern `keybind`, BL2 game mask, solo incompatibility metadata and enable/disable callbacks.
- [Willow2 manager stubs](https://github.com/bl-sdk/willow2-mod-manager/tree/master/stubs):
  `find_class`, `find_object`, iterator `find_all(exact=False)`, `_properties`, `_find`,
  `_find_prop`, `WrappedStruct._type`, distinct `WrappedArray`, SDK hook registration/status/removal.
- [Willow keybinds](https://github.com/bl-sdk/willow_keybinds/blob/master/__init__.py): keybinds
  dispatch from a PRE observer on `WillowGame.WillowUIInteraction:InputKey`.
- [UI utilities](https://github.com/bl-sdk/willow2-mod-manager/blob/master/src/ui_utils/hud_message.py):
  supported HUD notifications. In-game notification delivery remains untested.

Specific game functions from old mods are **candidates**, not verified game-build facts.
At runtime the prototype reflects each target's existence and parameters before adding an
observer; it records registration status and hit counts. A registered hook with zero hits
does not establish coverage. Unavailable classes/functions are reported and retried on
known reflected spawn/loading-complete lifecycle events. Collection itself does not retry
registration, load packages or execute candidate stage queries.

## Implemented evidence

Bounded PRE/POST observations around accept/complete/status events; POST observations of
reflected stage queries/setters, spawning, UI and rewards. No hook changes arguments,
return values or execution. Queries are labelled **observed SDK pipeline returns**, because
other mods can override them. No value is labelled an unmodified native return.

Mission comparisons join events and saved records by the exact mission object path. They
show definition stage, saved stage/status and existing lock flag together. No guessed
active-mission fallback, migration, acceptance correction or sidecar persistence is present.
Current screens and recent UI payloads are captured where accessible. Displayed Flash text,
effective resource pool regeneration and final XP/cash payment may remain inaccessible.

Bounded loaded-object samples cover regions, UVHM balance entries, nearby enemies/vehicles,
equipment generation and vendor stock. Bounds and truncation are explicit. Runtime UObject
references are not retained in history. Reports are checkpointed and atomically replaced;
failure in optional reads leaves partial evidence. Account IDs and full inventory/save dumps
are excluded; a controller-local save ID is hashed if that reflected field is available.

## Gate and next action

**Responsible floor: unresolved. SDK correction: none chosen. Gameplay success: unproven.**
No game runtime is available in this workspace. No in-game approaches have been attempted,
so a hard native blocker cannot yet be claimed either.

Collect the first offer/acceptance/journal reports on an unpatched level-1 UVHM character.
Identify the first observed transition to 50 for the same mission. Determine whether a
supported authoritative query, reflected bound or saved record explains it. Only then add
the smallest correction and test low-level UVHM, acceptance locks, and 50+ behaviour.
If the responsible native calculation is unhookable, document its exact evidence and discuss
that blocker with keogh. No executable or memory patch fallback is authorized or included.
