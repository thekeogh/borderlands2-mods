# Short probe/performance session — 0.1.3

All 12 reports from the opening replay were reviewed. The reward-card capture worked.
The first mission is truly stage 50, its UI receives 39,108 XP / 2,601 credits, and the
starter pistol is generated at stage/grade 50. Scaling is still unchanged in this build.

1. Fully exit the game, replace the installed package with 0.1.3, enable it and load the
   copied test character. The existing level-10 character is sufficient; no reset needed.
2. Once the HUD appears, press F10.
3. Mods → One Playthrough → **Export scaling probe JSON**. This separate read-only action
   calls the exact reflected mission/region getters and records their native output values.
4. Open a chest/container if one is conveniently available, then press F10. Tell us whether
   the gameplay hitch remains, and approximately how large the new reports are.
5. Return those JSONs through logs/. No mission completion, reward claim or combat required.

If a reset level-1 copy is already available, it is also useful: load it, wait for the first
mission assignment, F10, then run Export scaling probe JSON. Do not repeat the full opening
or edit the progressed character merely for this test.

F10 still only reads and exports; it never invokes the separate native-query probe. The
probe calls read-only level/region/reward getters, not setters, reward grants or save APIs.
It refuses unverified parameter layouts and reports missing data. The report distinguishes
query return values from named out parameters; invalid output values are marked as invalid.

The new capture omits polling/physics pickup hooks and uses small event snapshots. Reports
store each event once in event_table; event_ref is its sequence number. File naming and the
location remain `<game>/sdk_mods/settings/one_playthrough/diagnostics/`. No console commands.
The mod-menu export status shows the last result if the HUD notification isn't visible.

Armed mission capture remains available, but no new screen/turn-in test is needed this time.
Native scaling correction and actual performance improvement remain unverified until the
new reports arrive. Partial reports remain useful. Send any export failure text if needed.
