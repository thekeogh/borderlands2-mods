# One Playthrough 0.1.6 — keogh

Testing build for genuine UVHM from level 1. User-approved external executable patching
supersedes the original no-EXE prerequisite restriction. The mod does not patch files or memory.

1. Keep the verified patched executable installed as Borderlands2.exe. Its SHA-256 is
   `8bbe6e31f3bf5c9f83f9943c7c643ad4a950388ee03e4f4d705f4f10e9c3f1eb`.
   The mod does not verify that hash or the installed executable at runtime.
2. Fully quit the game. Replace the installed one_playthrough.sdkmod with this version
   under `<game>/sdk_mods/`. Remove duplicate installed copies; do not unzip the package.
3. Enable One Playthrough 0.1.6 before loading your copied level-1, genuine UVHM save.
   Ordinary New Game still starts Normal mode. Initial supported scope: solo BL2, OP selection 0.
4. For the next test, leave other scaling, difficulty and regen-changing mods disabled
   before launching. A full restart avoids carrying their earlier runtime edits forward.
5. Follow TESTING.md. F10 exports timestamped JSON under the SDK settings directory:
   `<game>/sdk_mods/settings/one_playthrough/diagnostics/`.
   Move the new reports into the project's logs folder after archiving the preceding batch.

The SDK change is only `GD_Playthrough3Tuning.Balance.BalanceMod_PT3`
`BalanceModifiers[0].MinEffectiveLevel`: 50 to 1. It makes the existing first UVHM tuning
entry eligible below 50. Native health, shield, damage, regeneration, XP, slag-related and
other tuning values are retained. Later thresholds 61 and 73 are retained. The normal
installed maximum character level is not changed. Native enemy/item levels and mission
acceptance records are not overwritten by this build. Existing owned items stay unchanged.

This activates UVHM tuning, so combat can be much harder than with the patched EXE alone.
Prior evidence establishes a threshold effect on XP evaluation; in-game health, regen,
spawn timing and player effects still require verification with this release.

The tuning asset is edited when available on enable and at verified load/spawn hooks.
No package is force-loaded. The report records pending assets, hook registration, the
last application boundary, current/original values and errors. Enable before loading and
reload the character after installing; existing actors are not retroactively rebuilt.

Disable attempts to restore the owned threshold. It preserves a threshold already set to
1 by another source and reports unexpected layouts or conflicting changes. Always fully
quit/restart after disabling: effects already applied to actors may persist. The external
EXE patch remains installed independently of the SDK mod.

Reports use disk JSON exclusively. HUD notifications may be unavailable in menus; the
mod option JSON export status / location shows export status. Capture next mission screen
supports mission cards that consume F10. Export scaling probe JSON is a separate read-only
query option. The completed threshold/native override experiments are hidden; do not run them.

This is not the final release. Mission locking across level-ups/reloads, level-50+ behaviour,
DLC travel, full UVHM fidelity and compatibility with other tuning mods remain unverified.
