# 0.1.6 — UVHM tuning below 50

Keep the verified patched EXE. Fully quit, install 0.1.6, and enable it before loading.
Other regen/scaling/difficulty mods should be disabled before launching this test.
You may continue the current copied save: the completed first mission is not rewritten.
Do not repeat the old threshold or native-override experiments.

1. Load your level-1 UVHM test save. Once the HUD appears, press F10.
2. Find living bullymongs. Press F10 while they are visible.
3. Damage one without killing it. Stop damaging it, keep watching its health bar for
   roughly 10 seconds, then press F10 again. Note whether its health recovered. If survival
   makes that impossible, capture what you can; the JSON does not measure regen over time.
4. Save-quit and reload the same save, then press F10 again after the HUD appears.
5. Move this batch's JSONs into logs and report regen behaviour. The first test needs no
   new mission completion or fresh save reset.

F10 is observational. It never applies tuning, invokes a native override, edits mission
records or grants rewards. Tuning is handled independently at enable/load/spawn boundaries.

Reports should show actual XP level 1, UVHM playthrough index 2, OP 0, enemy stages near
actual level, and implementation.uvhm_threshold.current=1 with state=active. The original
threshold should be 50 when this mod owns the edit; later tuning thresholds should remain
61 and 73. A state of pending/unavailable/conflict is evidence to investigate, not success.
The report includes all reflected fields of three regen initializers, not just ValueFormula.
A disabled ValueFormula alone does not establish that the entire initializer is disabled.

After this gate passes, the next acceptance test must cover a mission accepted before a
level-up and rewarded afterward, then save/reload and map travel. Do not assume the native
mission definition/record discrepancy is fixed by the EXE or by this threshold change.
